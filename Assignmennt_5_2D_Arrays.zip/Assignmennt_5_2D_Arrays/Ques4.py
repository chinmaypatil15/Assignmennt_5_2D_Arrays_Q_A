def findDisappearedNumbers(nums1, nums2):
    set1 = set(nums1)
    set2 = set(nums2)
    result1 = [x for x in nums1 if x not in set2]
    result2 = [x for x in nums2 if x not in set1]
    return [result1, result2]
# Test example
nums1 = [1, 2, 3]
nums2 = [2, 4, 6]
result = findDisappearedNumbers(nums1, nums2)
print(result)
