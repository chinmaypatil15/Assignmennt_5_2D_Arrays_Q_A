def arrangeCoins(n):
    k = 0
    while (k * (k + 1)) // 2 <= n:
        k += 1
    return k - 1
# Test example
n = 5
result = arrangeCoins(n)
print(result)
