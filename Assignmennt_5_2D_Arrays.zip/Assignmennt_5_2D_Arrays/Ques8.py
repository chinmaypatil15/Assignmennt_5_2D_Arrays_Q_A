from collections import defaultdict
def findOriginalArray(changed):
    if len(changed) % 2 != 0:
        return []
    countMap = defaultdict(int)
    for num in changed:
        countMap[num] += 1
    original = []
    for num in changed:
        if countMap[num] > 0 and countMap[num // 2] > 0:
            original.append(num)
            countMap[num] -= 1
            countMap[num // 2] -= 1
        else:
            return []
    return original
# Test example
changed = [1, 3, 4, 2, 6, 8]
result = findOriginalArray(changed)
print(result)
